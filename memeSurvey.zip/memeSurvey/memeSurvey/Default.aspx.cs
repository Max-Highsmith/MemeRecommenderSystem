﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace memeSurvey
{
    public partial class _Default : Page
    {
        List<string[]> allData;
        List<string> urls;
        List<int> likes;
        List<List<int>> users;
        List<int[]> indexer;
        List<List<int>> bfs;

        protected void Page_Init(object sender, EventArgs e)
        {
            loadSurveyData();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // First Run
                string url = urls[pickFirstMeme()];
                Image placeHolder = new Image();
                placeHolder.ImageUrl = url;
                bodyBody.Controls.Add(placeHolder);
                Session["priorMeme"] = pickFirstMeme();
            }
            else
            {
                // Subsequent Runs
                indexer = (List<int[]>)Session["indexer"];
                if (indexer == null)
                    indexer = new List<int[]>();
                bfs = (List<List<int>>)Session["bfs"];
                if (bfs == null)
                    bfs = new List<List<int>>();

            }
        }

        public void loadSurveyData()
        {
            var parser = new Microsoft.VisualBasic.FileIO.TextFieldParser(System.AppDomain.CurrentDomain.BaseDirectory.ToString() + "/memeSurveyData.csv");
            parser.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited;
            parser.SetDelimiters(new string[] { "," });
            allData = new List<string[]>();
            while (!parser.EndOfData)
            {
                string[] row = parser.ReadFields();
                allData.Add(row);
            }
            urls = new List<string>();
            likes = new List<int>();
            users = new List<List<int>>();

            for (int i = 1; i < allData.Count; i++)
            {
                urls.Add(allData[i][0]);
                likes.Add(Convert.ToInt32(allData[i][1]));
            }
            for (int i = 3; i < allData[0].Length; i++)
            {
                List<int> temp = new List<int>();
                for (int j = 1; j < allData.Count; j++)
                    temp.Add(Convert.ToInt32(allData[j][i]));
                users.Add(temp);
            }
            // The following to be removed
            //Table tmpTable = new Table();
            //for (int i = 0; i < users.Count; i++)
            //{
            //    TableRow tr = new TableRow();
            //    for (int j = 0; j < users[0].Count; j++)
            //    {
            //        TableCell tc = new TableCell();
            //        tc.Text = Convert.ToString(users[i][j]);
            //        tr.Cells.Add(tc);
            //    }
            //    tmpTable.Rows.Add(tr);
            //}
            //bodyBody.Controls.Add(tmpTable);
        }

        private int pickFirstMeme()
        {
            int chosen = 0;
            int likers = 0;
            for (int i = 0; i < likes.Count; i++)
            {
                if (likes[i] > likers)
                {
                    likers = likes[i];
                    chosen = i;
                }
            }
            return chosen;
        }

        private int[] nextRecommend(List<List<int>> users, List<int> index)
        {
            int[] recommend = { 0, 0 };
            for (int i = 0; i < users[0].Count; i++)
            {
                int hits = 0;
                bool unpicked = true;
                for (int j = 0; j < index.Count; j++)
                    if (i == index[j])
                        unpicked = false;
                for (int j = 0; j < users.Count; j++)
                    if (users[j][i] == 1)
                        hits++;
                if (hits > recommend[1] && unpicked)
                {
                    recommend[0] = i;
                    recommend[1] = hits;
                }
            }
            return recommend;
        }

        private int getMemeNum(string url)
        {
            int memeNum = -1;
            for (int i = 0; i < urls.Count; i++)
                if (urls[i] == url)
                    memeNum = i;
            return memeNum;
        }

        private List<List<int>> userLikes(int index)
        {
            List<List<int>> incrowd = new List<List<int>>();
            for (int i = 0; i < users.Count; i++)
                if (users[i][index] == 1)
                    incrowd.Add(users[i]);
            return incrowd;
        }

        private List<List<int>> userHates(int index)
        {
            List<List<int>> incrowd = new List<List<int>>();
            for (int i = 0; i < users.Count; i++)
                if (users[i][index] != 1)
                    incrowd.Add(users[i]);
            return incrowd;
        }

        private bool checkPreference(List<int> userPref, List<int[]> ind)
        {
            bool better = false;
            int quota = 0;
            for (int i = 0; i < ind.Count; i++)
                if (userPref[ind[i][0]] == -1 || userPref[ind[i][0]] == ind[i][1])
                    quota++;
            if (quota / ind.Count >= .5)
                better = true;
            return better;
        }

        private bool noduplicates(List<List<int>> currFriends, List<int> prefs)
        {
            bool notPresent = true;
            for (int i = 0; i < currFriends.Count; i++)
            {
                int exact = 0;
                for (int j = 0; j < currFriends[0].Count; j++)
                    if (currFriends[i][j] == prefs[j])
                        exact++;
                if (exact == currFriends[0].Count)
                    notPresent = false;
            }
            return notPresent;
        }

        private List<List<int>> unionFriends(List<List<int>> basefriends, List<List<int>> newfriends, List<int[]> ind)
        {
            List<List<int>> bffs = new List<List<int>>();
            for (int i = 0; i < basefriends.Count; i++)
                if (checkPreference(basefriends[i], ind))
                    bffs.Add(basefriends[i]);
            for (int i = 0; i < newfriends.Count; i++)
                if (noduplicates(bffs, newfriends[i]))
                    if (checkPreference(newfriends[i], ind))
                        bffs.Add(newfriends[i]);
            return bffs;
        }

        private List<int[]> createOptions(List<List<int>> peerGroup, List<int[]> ind)
        {
            List<int[]> choices = new List<int[]>();
            List<int> expIndex = new List<int>();
            for (int i = 0; i < ind.Count; i++)
                expIndex.Add(ind[i][0]);
            for (int i = 0; i < 4; i++)
            {
                int[] newChoice = nextRecommend(peerGroup, expIndex);
                choices.Add(newChoice);
            }
            return choices;
        }

        private int weightedFriendChoice(List<List<int>> bffs, List<int[]> options)
        {
            int finalchoice = 0;
            for (int i = 0; i < options.Count; i++)
            {
                int weight = options[i][1];
                for (int j = 0; j < bffs.Count; j++)
                    if (bffs[j][options[i][0]] == 1)
                        weight++;
                options[i][1] = weight;
            }
            int wght = 0;
            for (int i = 0; i < options.Count; i++)
                if (options[i][1] > wght)
                {
                    finalchoice = options[i][0];
                    wght = options[i][1];
                }
            return finalchoice;
        }
        #region oldstuff
        /*
        List<string> urlsInOrder;
        List<CheckBox> allCbs;
        protected void Page_Init(object sender, EventArgs e)
        {
            urlsInOrder = new List<string>();
            allCbs = new List<CheckBox>();
            var parser = new Microsoft.VisualBasic.FileIO.TextFieldParser(System.AppDomain.CurrentDomain.BaseDirectory.ToString() + "/memelist.csv");
            parser.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited;
            parser.SetDelimiters(new string[] { ";" });
            List<string> urls = new List<string>();
            while (!parser.EndOfData)
            {
                string[] row = parser.ReadFields();
                string url = row[0];
                urls.Add(url);
            }
            int cap = 50;

            Random rnd = new Random();

            List<int> originals = new List<int>();

            List<string> myPics = new List<string>();
            if (Session["originalOrder"] == null)
            {
                for (int i = 0; i < cap; i++)
                {
                    bool rep = new bool();
                    string nextUrl = null;
                    int next = 0;
                    do
                    {
                        rep = false;
                        next = rnd.Next(0, urls.Count);
                        nextUrl = urls[next];
                        for (int j = 0; j < myPics.Count; j++)
                        {
                            if (myPics[j] == nextUrl)
                                rep = true;
                        }
                    } while (rep);
                    myPics.Add(nextUrl);
                    originals.Add(next);
                }
                Session["originalOrder"] = originals;
            }
            else
            {
                originals = (List<int>)Session["originalOrder"];
                for (int i = 0; i < originals.Count; i++)
                {
                    myPics.Add(urls[originals[i]]);
                }
            }
            for (int i = 0; i < myPics.Count; i++)
            {
                HtmlGenericControl divContainer = new HtmlGenericControl("div");
                divContainer.Attributes.Add("class", "row");

                HtmlGenericControl imageContainer = new HtmlGenericControl("div");
                imageContainer.Attributes.Add("class", "col-mid-4");

                HtmlGenericControl approveContainer = new HtmlGenericControl("div");
                approveContainer.Attributes.Add("class", "col-mid-4");

                Image placeHolder = new Image();
                placeHolder.ImageUrl = myPics[i];
                placeHolder.Width = 250;

                urlsInOrder.Add(myPics[i]);
                imageContainer.Controls.Add(placeHolder);
                
                Label cbLabel = new Label();
                cbLabel.Text = "Approve:";
                CheckBox cbCheck = new CheckBox();
                allCbs.Add(cbCheck);

                approveContainer.Controls.Add(cbLabel);
                approveContainer.Controls.Add(cbCheck);

                divContainer.Controls.Add(imageContainer);
                divContainer.Controls.Add(approveContainer);

                bodyBody.Controls.Add(divContainer);
            }
            
        }

        public void sendResults(string sender, List<string> urls, List<bool> approves)
        {
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            mail.To.Add("jonmichaelrutter@gmail.com");
            mail.From = new System.Net.Mail.MailAddress("jonmichaelrutter@hotmail.com", "Results", System.Text.Encoding.UTF8);
            mail.Subject = sender + " results";
            mail.SubjectEncoding = System.Text.Encoding.UTF8;
            string bodyString = "<table>";
            for (int i = 0; i < urls.Count; i++)
            {
                bodyString += "<tr><td>" + urls[i];
                bodyString += "</td><td>" + approves[i] + "</td></tr>";
            }
            mail.Body = bodyString;
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            SmtpClient client = new SmtpClient();
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            client.Credentials = new System.Net.NetworkCredential("jonmichaelrutter@hotmail.com", "p9m5wd6h9e33tr02");
            client.Port = 587;
            client.Host = "smtp.live.com";
            client.EnableSsl = true;
            try
            {
                client.Send(mail);
            }
            catch (Exception ex)
            {
                string errorMessage = string.Empty;
                while (ex != null)
                {
                    errorMessage += ex.ToString();
                    ex = ex.InnerException;
                }
            }
        }*/
        #endregion

        //public void setupMemeDB(memedatabaseEntities db, List<string> urls)
        //{
        //    for (int i = 0; i < urls.Count; i++)
        //    {
        //        Meme temp = new Meme();
        //        temp.MemeUrl = urls[i];
        //        db.Meme.Add(temp);
        //        db.SaveChanges();
        //    }
        //}

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Hate It
            int prior = (int)Session["priorMeme"];
            indexer.Add(new int[] { prior, 0 });
            Session["indexer"] = indexer;
            List<List<int>> haters = userHates(prior);
            List<List<int>> bffs = unionFriends(bfs, haters, indexer);
            int choice = weightedFriendChoice(bffs, createOptions(haters, indexer));
            Image ph = new Image();
            ph.ImageUrl = urls[choice];
            Session["priorMeme"] = choice;
            bodyBody.Controls.Add(ph);
            Session["bfs"] = bffs;
            /*List<bool> answers = new List<bool>();
            for (int i = 0; i < allCbs.Count; i++)
            {
                if (allCbs[i].Checked)
                    answers.Add(true);
                else
                    answers.Add(false);
            }
            bodyHeader.InnerText = "Thank you for participating!";
            Button1.Enabled = false;*/
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            // Loved It
            int prior = (int)Session["priorMeme"];
            indexer.Add(new int[] { prior, 1 });
            Session["indexer"] = indexer;
            List<List<int>> lovers = userLikes(prior);
            List<List<int>> bffs = unionFriends(bfs, lovers, indexer);
            int choice = weightedFriendChoice(bffs, createOptions(lovers, indexer));
            Image ph = new Image();
            ph.ImageUrl = urls[choice];
            Session["priorMeme"] = choice;
            bodyBody.Controls.Add(ph);
            Session["bffs"] = bffs;
        }

        //protected void Button2_Click(object sender, EventArgs e)
        //{
        //    memedatabaseEntities db = new memedatabaseEntities();
        //    var parser = new Microsoft.VisualBasic.FileIO.TextFieldParser(System.AppDomain.CurrentDomain.BaseDirectory.ToString() + "/memelist.csv");
        //    parser.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited;
        //    parser.SetDelimiters(new string[] { ";" });
        //    List<string> urls = new List<string>();
        //    while (!parser.EndOfData)
        //    {
        //        string[] row = parser.ReadFields();
        //        string url = row[0];
        //        urls.Add(url);
        //    }
        //    setupMemeDB(db, urls);
        //}
        //public System.Drawing.Image DownloadImageFromUrl(string imageUrl){
        //    System.Drawing.Image image = null;
        //    try
        //    {
        //        System.Net.HttpWebRequest webRequest = (System.Net.HttpWebRequest)System.Net.HttpWebRequest.Create(imageUrl);
        //        webRequest.AllowWriteStreamBuffering = true;
        //        webRequest.Timeout = 30000;

        //        System.Net.WebResponse webResponse = webRequest.GetResponse();

        //        System.IO.Stream stream = webResponse.GetResponseStream();

        //        image = System.Drawing.Image.FromStream(stream);

        //        webResponse.Close();
        //    }
        //    catch(Exception ex)
        //    {
        //        return null;
        //    }
        //    return image;
        //    }
    }
}